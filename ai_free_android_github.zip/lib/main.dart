import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

void main() => runApp(const AIFreeApp());

class AIFreeApp extends StatelessWidget {
  const AIFreeApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Free',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0D12),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6D5CFF), brightness: Brightness.dark),
        fontFamily: 'Roboto',
      ),
      home: const Shell(),
    );
  }
}

class ChatMessage {
  final String role;
  final String text;
  final String? imagePath;
  ChatMessage(this.role, this.text, {this.imagePath});
}

class SettingsStore {
  String token = '';
  String model = 'gpt-5.6-sol';
  String baseUrl = 'https://agentrouter.org/v1/chat/completions';
  bool speakAnswers = true;
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('token') ?? '';
    model = p.getString('model') ?? 'gpt-5.6-sol';
    baseUrl = p.getString('baseUrl') ?? 'https://agentrouter.org/v1/chat/completions';
    speakAnswers = p.getBool('speakAnswers') ?? true;
  }
  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('token', token);
    await p.setString('model', model);
    await p.setString('baseUrl', baseUrl);
    await p.setBool('speakAnswers', speakAnswers);
  }
}

final settings = SettingsStore();

class AiService {
  static const system = 'Ты AI Free — дружелюбный, умный ИИ-помощник. Отвечай по-русски, помогай с проектами, кодом, идеями, фото, планами. Будь конкретным, полезным и вдохновляющим.';
  Future<String> ask(List<ChatMessage> messages) async {
    if (settings.token.trim().isEmpty) return demo(messages.last.text);
    final body = {
      'model': settings.model,
      'messages': [
        {'role': 'system', 'content': system},
        ...messages.where((m) => m.text.trim().isNotEmpty).map((m) => {'role': m.role == 'user' ? 'user' : 'assistant', 'content': m.text})
      ],
      'temperature': 0.7,
    };
    final res = await http.post(Uri.parse(settings.baseUrl), headers: {
      'Authorization': 'Bearer ${settings.token}',
      'Content-Type': 'application/json',
    }, body: jsonEncode(body)).timeout(const Duration(seconds: 45));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      return 'Ошибка API: ${res.statusCode}\n${res.body}';
    }
    final data = jsonDecode(res.body);
    return data['choices']?[0]?['message']?['content']?.toString() ?? 'Ответ пустой. Проверь модель или API.';
  }
  String demo(String q) {
    final lower = q.toLowerCase();
    if (lower.contains('план')) return 'Вот план:\n1) Определи цель.\n2) Разбей задачу на этапы.\n3) Сделай MVP.\n4) Проверь результат.\n5) Улучши дизайн и функции.';
    if (lower.contains('код')) return 'Я помогу с кодом. Опиши язык, ошибку или цель — и я предложу структуру, пример и исправления.';
    if (lower.contains('фото')) return 'Для фото можно добавить: описание изображения, поиск дублей, оценку качества, сравнение похожести и выбор лучшего кадра.';
    return 'Я AI Free в демо-режиме. Вставь AgentRouter token в настройках, и я начну отвечать как настоящий ИИ. Сейчас могу помочь с идеями, планами, кодом и проектами.';
  }
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState() => _ShellState(); }
class _ShellState extends State<Shell> {
  int tab = 0;
  @override void initState(){ super.initState(); settings.load().then((_)=>setState((){})); }
  @override Widget build(BuildContext context){
    final pages = [const ChatPage(), const ToolsPage(), const MemoryPage(), const SettingsPage()];
    return Scaffold(
      body: Container(decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment.topRight, radius: 1.2, colors: [Color(0x554F7DFF), Color(0xFF11131A), Color(0xFF0B0D12)])), child: SafeArea(child: pages[tab])),
      bottomNavigationBar: NavigationBar(backgroundColor: const Color(0xEE171923), selectedIndex: tab, onDestinationSelected: (i)=>setState(()=>tab=i), destinations: const [
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Чат'),
        NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Tools'),
        NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), label: 'Память'),
        NavigationDestination(icon: Icon(Icons.settings), label: 'Настройки'),
      ]),
    );
  }
}

class ChatPage extends StatefulWidget { const ChatPage({super.key}); @override State<ChatPage> createState()=>_ChatPageState(); }
class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController(); final ai = AiService(); final tts = FlutterTts(); final speech = stt.SpeechToText();
  final messages = <ChatMessage>[ChatMessage('assistant','Я AI Free — твой личный помощник. Могу помогать с проектами, кодом, идеями, фото и планами.')];
  bool loading=false, listening=false; XFile? picked;
  Future<void> send([String? preset]) async { final text=(preset??input.text).trim(); if(text.isEmpty && picked==null)return; setState((){messages.add(ChatMessage('user', text.isEmpty?'[Фото для анализа]':text, imagePath:picked?.path)); input.clear(); picked=null; loading=true;}); final answer=await ai.ask(messages); setState((){messages.add(ChatMessage('assistant', answer)); loading=false;}); if(settings.speakAnswers){ await tts.setLanguage('ru-RU'); await tts.speak(answer.substring(0, answer.length>700?700:answer.length)); }}
  Future<void> mic() async { if(!listening){ final ok=await speech.initialize(); if(ok){ setState(()=>listening=true); speech.listen(localeId:'ru_RU', onResult:(r){input.text=r.recognizedWords;}); }} else { await speech.stop(); setState(()=>listening=false); }}
  Future<void> pickImage() async { final img=await ImagePicker().pickImage(source: ImageSource.gallery); if(img!=null)setState(()=>picked=img); }
  @override Widget build(BuildContext context){return Column(children:[
    Padding(padding: const EdgeInsets.fromLTRB(18,18,18,8), child: Row(children:[const _Logo(), const SizedBox(width:12), const Expanded(child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text('AI Free', style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)), Text('бесплатный ИИ-помощник', style:TextStyle(color:Colors.white60))])), IconButton(onPressed:()=>send('Сделай мне план проекта'), icon: const Icon(Icons.bolt))])),
    SizedBox(height:104, child: ListView(scrollDirection:Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal:16), children:[_Quick('💡','Идея',()=>send('Придумай крутую идею проекта')),_Quick('🧠','Думай глубже',()=>send('Проанализируй глубже')),_Quick('💻','Код',()=>send('Помоги с кодом')),_Quick('📷','Фото',pickImage)])),
    Expanded(child: Container(margin: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFF7F8FB), borderRadius: BorderRadius.circular(28)), child: ListView.builder(padding: const EdgeInsets.all(14), itemCount: messages.length+(loading?1:0), itemBuilder:(c,i){ if(i>=messages.length)return const _Bubble(text:'Думаю...', user:false); final m=messages[i]; return _Bubble(text:m.text,user:m.role=='user',imagePath:m.imagePath); }))),
    if(picked!=null) Padding(padding: const EdgeInsets.symmetric(horizontal:16), child: Row(children:[const Icon(Icons.image,color:Colors.cyanAccent), const SizedBox(width:8), Expanded(child:Text(picked!.name)), IconButton(onPressed:()=>setState(()=>picked=null), icon: const Icon(Icons.close))])),
    Padding(padding: const EdgeInsets.fromLTRB(14,0,14,14), child: Row(children:[IconButton(onPressed:pickImage, icon: const Icon(Icons.add_photo_alternate)), Expanded(child: TextField(controller:input, decoration: InputDecoration(hintText:'Напиши сообщение...', filled:true, fillColor:Colors.white, hintStyle: const TextStyle(color:Colors.black45), border:OutlineInputBorder(borderRadius:BorderRadius.circular(20), borderSide:BorderSide.none)), style: const TextStyle(color:Colors.black))), IconButton(onPressed:mic, icon: Icon(listening?Icons.stop_circle:Icons.mic, color:listening?Colors.redAccent:Colors.cyanAccent)), IconButton(onPressed:()=>send(), icon: const Icon(Icons.send, color:Colors.cyanAccent))]))
  ]);}
}

class _Bubble extends StatelessWidget{final String text;final bool user;final String? imagePath;const _Bubble({required this.text,required this.user,this.imagePath});@override Widget build(BuildContext context){return Align(alignment:user?Alignment.centerRight:Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(vertical:6), padding: const EdgeInsets.all(12), constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width*.78), decoration: BoxDecoration(color:user?const Color(0xFF2783DE):const Color(0xFFEDEFF5), borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[if(imagePath!=null) ClipRRect(borderRadius:BorderRadius.circular(12), child: Image.file(File(imagePath!), height:150, fit:BoxFit.cover)), Text(text, style:TextStyle(color:user?Colors.white:Colors.black87, height:1.35))])));}}
class _Quick extends StatelessWidget{final String e,t;final VoidCallback onTap;const _Quick(this.e,this.t,this.onTap);@override Widget build(BuildContext c)=>GestureDetector(onTap:onTap, child:Container(width:132, margin: const EdgeInsets.only(right:10), padding: const EdgeInsets.all(14), decoration:BoxDecoration(color:Colors.white.withOpacity(.08), border:Border.all(color:Colors.white24), borderRadius:BorderRadius.circular(18)), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text(e,style:const TextStyle(fontSize:24)), const Spacer(), Text(t,style:const TextStyle(fontWeight:FontWeight.bold))])));}
class _Logo extends StatelessWidget{const _Logo();@override Widget build(BuildContext c)=>Container(width:48,height:48,decoration:BoxDecoration(borderRadius:BorderRadius.circular(16), gradient: const LinearGradient(colors:[Color(0xFF54E6FF),Color(0xFF7C5CFF),Color(0xFFFF4FC4)]), boxShadow:[BoxShadow(color:const Color(0xFF7C5CFF).withOpacity(.5), blurRadius:22)]));}

class ToolsPage extends StatelessWidget{const ToolsPage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children: const [Text('Tools',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900)), _Tool('💡','Генератор идей','Придумывает проекты, бизнес-идеи и планы.'), _Tool('📷','Анализ фото','Добавь фото в чат и попроси анализ.'), _Tool('💻','Помощь с кодом','Ошибки, проекты, сайты, приложения.'), _Tool('📝','Тексты','Письма, посты, описания, переводы.')]);}
class _Tool extends StatelessWidget{final String e,t,d;const _Tool(this.e,this.t,this.d);@override Widget build(BuildContext c)=>Card(color:Colors.white.withOpacity(.08),child:ListTile(leading:Text(e,style:const TextStyle(fontSize:28)),title:Text(t,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(d)));}
class MemoryPage extends StatefulWidget{const MemoryPage({super.key});@override State<MemoryPage> createState()=>_MemoryPageState();}
class _MemoryPageState extends State<MemoryPage>{final ctrl=TextEditingController();List<String> mem=[];@override void initState(){super.initState();SharedPreferences.getInstance().then((p){setState(()=>mem=p.getStringList('memory')??[]);});}Future save()async{final p=await SharedPreferences.getInstance();await p.setStringList('memory',mem);}@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Память',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900)),const Text('Сохраняй важные факты о себе и проектах.'),Row(children:[Expanded(child:TextField(controller:ctrl,decoration:const InputDecoration(hintText:'Например: я делаю AI Free'))),IconButton(onPressed:(){if(ctrl.text.trim().isNotEmpty){setState(()=>mem.add(ctrl.text.trim()));ctrl.clear();save();}},icon:const Icon(Icons.add))]),Expanded(child:ListView(children:[for(final m in mem) Card(child:ListTile(title:Text(m),trailing:IconButton(icon:const Icon(Icons.delete),onPressed:(){setState(()=>mem.remove(m));save();})))]) )]));}
class SettingsPage extends StatefulWidget{const SettingsPage({super.key});@override State<SettingsPage> createState()=>_SettingsPageState();}
class _SettingsPageState extends State<SettingsPage>{late TextEditingController token,base;@override void initState(){super.initState();token=TextEditingController(text:settings.token);base=TextEditingController(text:settings.baseUrl);}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Настройки',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900)),TextField(controller:token,obscureText:true,decoration:const InputDecoration(labelText:'AgentRouter Token')),TextField(controller:base,decoration:const InputDecoration(labelText:'Base URL')),DropdownButtonFormField(value:settings.model,items:['gpt-5.6-sol','claude-opus-5','claude-opus-4-8'].map((m)=>DropdownMenuItem(value:m,child:Text(m))).toList(),onChanged:(v)=>setState(()=>settings.model=v!),decoration:const InputDecoration(labelText:'Модель')),SwitchListTile(value:settings.speakAnswers,title:const Text('Озвучивать ответы'),onChanged:(v)=>setState(()=>settings.speakAnswers=v)),FilledButton(onPressed:(){settings.token=token.text.trim();settings.baseUrl=base.text.trim();settings.save();ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Настройки сохранены')));},child:const Text('Сохранить'))]);}
